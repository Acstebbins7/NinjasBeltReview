package com.acstebbins.ninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
