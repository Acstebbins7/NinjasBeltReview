package com.acstebbins.ninjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.acstebbins.ninjas.models.Ninja;
import com.acstebbins.ninjas.repositories.NinjaRepository;


@Service
public class NinjaService {
	
	private final NinjaRepository ninjaRepo;
	
	public NinjaService(NinjaRepository ninjaRepo) {
		this.ninjaRepo = ninjaRepo;
	}
	
	public Ninja create(Ninja newNinja) {
		return ninjaRepo.save(newNinja);
	}
	
	public List<Ninja> getAll() {
		return (List<Ninja>) ninjaRepo.findAll();
	}
	
	public Ninja getOne(Long id) {
		Optional<Ninja> ninja = ninjaRepo.findById(id); 
//		if(ninja.isPresent()) {
//			return ninja.get();
//		} else {
//			return null;
//		}
//		Make a React type Ternary \/
		return ninja.isPresent() ? ninja.get() : null;
	}
	
	public Ninja update(Ninja toUpdate) {
		return ninjaRepo.save(toUpdate);
	}
	
	public void remove(Long id) {
		ninjaRepo.deleteById(id);
	}
	
	public List<Ninja> topNinjas3() {
		return ninjaRepo.top3Ninjas();
	}

}
